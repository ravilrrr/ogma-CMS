<?php

// Login trasnlations 
$lang = array
(
    "BOOTSTRAP_LOGO" => "Select a Logo",
    "BOOTSTRAP_TITLE" => "Website Title",
    "BOOTSTRAP_THEME" => "Select a Theme",
    "BOOTSTRAP_FOOTER" => "Footer Text"
);

