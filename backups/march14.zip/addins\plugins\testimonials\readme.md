### Introduction

This plugin allows you to save testimonial information from customers for display on your site. 

### Fields

The following fields are available 

* who
* what
* when
* company
* email
* active 

### Usage

    Testimonials::getTestimonials($num, $random);  

* $num, Number of records to retrieve
* $random, set true to randomize the results
