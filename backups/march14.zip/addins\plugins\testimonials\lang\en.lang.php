<?php

// Login trasnlations 
$lang = array
(
    "TESTIMONIALS_TESTIMONIALS" => "Testimonials",
    "TESTIMONIALS_WHO" => "Customer Name",
    "TESTIMONIALS_WHAT" => "Testimonial Details",
    "TESTIMONIALS_WHEN" => "Date",
    "TESTIMONIALS_EMAIL" => "Email",
    "TESTIMONIALS_COMPANY" => "Company",
  	"TESTIMONIALS_CREATE" => "Create Testimonial",
    "TESTIMONIALS_EDIT" => "Edit Testimonial"     
);



